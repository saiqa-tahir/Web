const express = require('express');
const router = express.Router();
const SubmittedData = require('../models/submittedData');

// GET route to fetch submitted data
router.get('/', async (req, res) => {
  try {
    const submittedData = await SubmittedData.find();
    res.json(submittedData);
  } catch (err) {
    console.error('Error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
