// Backend/controllers/communityController.js

