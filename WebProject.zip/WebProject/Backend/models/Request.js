const express = require('express');
const router = express.Router();
const SubmittedData = require('./models/request');

// POST route to save submitted data
router.post('/', async (req, res) => {
  try {
    // Create a new instance of SubmittedData model with the submitted data
    const newSubmittedData = new SubmittedData(req.body);
    // Save the data to the database
    await newSubmittedData.save();
    res.status(201).json({ message: 'Data saved successfully' });
  } catch (err) {
    console.error('Error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET route to fetch submitted data
router.get('/', async (req, res) => {
  try {
    // Fetch all submitted data from the database
    const submittedData = await SubmittedData.find();
    res.json(submittedData);
  } catch (err) {
    console.error('Error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
