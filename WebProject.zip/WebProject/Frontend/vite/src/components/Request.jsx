import React, { useState, useEffect } from 'react';

const Request = () => {
  const [submittedData, setSubmittedData] = useState([]);

  useEffect(() => {
    const fetchSubmittedData = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/request');
        if (response.ok) {
          const data = await response.json();
          setSubmittedData(data);
        } else {
          console.error('Failed to fetch submitted data');
        }
      } catch (err) {
        console.error('Error:', err);
      }
    };

    fetchSubmittedData();
  }, []);

  return (
    <div>
      {/* Display submitted data */}
      {submittedData.map((data, index) => (
        <div key={index}>
          <p>Title: {data.title}</p>
        </div>
      ))}
    </div>
  );
}

export default Request;
