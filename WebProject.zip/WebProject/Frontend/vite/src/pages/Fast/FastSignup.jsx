import React from 'react'
import SignUpForm from '../../components/SignUpForm'
const FastSignup = () => {
  return (
    <div>
          <SignUpForm redirectPath="/fastlogin" path="http://localhost:5000/api/fastlogin" dashboard="/fastdashboard"/>
    </div>
  )
}

export default FastSignup