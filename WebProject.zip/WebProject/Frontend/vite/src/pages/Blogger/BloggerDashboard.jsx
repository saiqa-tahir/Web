import React from 'react'
import BloggerNavbar from './BloggerNavbar'
import DashboardPage from '../DashboardPage'
const BloggerDashboard = () => {
  return (
    <div>
        <BloggerNavbar/>
    <DashboardPage/>
    </div>
  )
}

export default BloggerDashboard