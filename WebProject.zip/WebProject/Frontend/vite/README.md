* Run npm install command in both backend and vite folders
* for backend run "npm start" command
* for vite run "npm run dev" command